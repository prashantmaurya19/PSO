package com.PlayChess.com.ViewService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
